package com.ecommerce.projeto.model;

public enum Role {
    USER,
    ADMIN
}